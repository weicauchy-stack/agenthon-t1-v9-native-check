# T3 v2 原生 QA 草稿

尚未发布，尚未在原生 amd64 上执行。

拟在现有公共 QA 仓库 `weicauchy-stack/agenthon-t1-v9-native-check` 中新增 `t3-v2/`、`t3-v2-manifest.json` 和 `.github/workflows/t3-v2-native.yml`；不会覆盖既有 T1/T2 文件。工作流只允许手动触发，输入为获准公开的镜像 repository@sha256 digest。正式发布前还需检查远端路径是否冲突。

候选 amd64 镜像本地标识见上层测试报告。原生执行前需要先把该镜像发布到获准的公开容器仓库；当前未执行此步骤。公开镜像会包含候选程序代码。

QA 在原生 Linux x86_64 上检查：平台、接口、无 VOLUME、冻结源码哈希、公开 71 单元每题五次、官方语义/输出清理、重复哈希与 300 秒约束。控制器下载并核对锁定的官方公共源码与 LFS 对象，不上传任务数据。模型调用在 QA 控制器中硬性禁用，不包含凭证读取程序。

本地 `native_validate.py --check-bundle` 仅验证草稿文件哈希，不能证明原生运行通过。原生 CI 也不提供 Final 排名或官方可信计时。

发布布局：源码保留在根目录 `t3-v2-native-qa.zip` 内，工作流单独放在 `.github/workflows/t3-v2-native.yml`。CI 解包后验证每个文件哈希。此布局避免浏览器上传时丢失嵌套目录。

## Diagnostic update

This revision adds host-only progress messages, 50-second resource heartbeats, 120-second host stack dumps, and retained container commands/states. The participant image, official scorers, gates, timing bounds, isolation settings, five repeats and frozen 71-unit roster are unchanged. A stalled or cancelled run remains separate and does not count as a complete pass.

## Final runtime parity (27 October)

Uses the unchanged accepted image with platform UID/GID 65534:65534 and /tmp limited to 64 MiB, noexec,nosuid,nodev. All 71 units and five repeats are kept. Official source, gates and container timing are unchanged. Raw output copies are retained to avoid modifying permissions on container-owned batch directories; sanitized output and hashes remain independently validated. No signing or competition upload.
