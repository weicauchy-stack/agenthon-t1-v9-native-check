"""Resolve immutable organizer snapshots and separate participant run artifacts."""
from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUNS = ROOT.parent / "outputs" / "final_development"
TRACKS = {"t1": "coding", "t2": "forecasting", "t3": "simulation"}


def sources() -> dict:
    return json.loads((ROOT / "sources.lock.json").read_text())


def official(key: str) -> Path:
    path = ROOT / sources()["repositories"][key]["path"]
    if not path.is_dir():
        raise FileNotFoundError(f"Organizer snapshot missing: {path}")
    return path


def unit_path(track: str, unit: str) -> Path:
    path = official(track) / "units" / unit
    if Path(unit).name != unit or not (path / "card.toml").is_file():
        raise ValueError(f"Unknown public {track} unit: {unit}")
    return path


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n")
