"""Participant development tools; official scoring remains in the organizer packages."""
