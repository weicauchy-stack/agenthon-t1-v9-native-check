"""Native-only CI entry; --check-bundle is offline and makes no native claim."""
from __future__ import annotations
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import urllib.request

BASE=Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-bundle',action='store_true')
    args=parser.parse_args()
    manifest=json.loads((BASE.parent/'t3-v2-manifest.json').read_text())
    for name,digest in manifest['file_sha256'].items():
        path=BASE.parent/name
        if not path.resolve().is_relative_to(BASE.parent.resolve()):
            raise RuntimeError('Bundle member escaped QA root')
        if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
            raise RuntimeError('QA bundle hash mismatch: '+name)
    if args.check_bundle:
        print(json.dumps({'bundle_verified':True,'native_amd64_validated':False,'executed':False}))
        return 0
    if sys.version_info<(3,13) or platform.system()!='Linux' or platform.machine().lower() not in {'x86_64','amd64'}:
        raise RuntimeError('Run on native Linux x86_64 with Python 3.13; emulation is not acceptance')
    image=os.environ.get('T3_IMAGE','')
    if not re.fullmatch(r'[a-z0-9._/-]+@sha256:[0-9a-f]{64}',image):
        raise RuntimeError('T3_IMAGE must be an approved publicly pullable repository@sha256:digest')
    info=json.loads(subprocess.run(['docker','info','--format','{{json .}}'],check=True,capture_output=True,text=True).stdout)
    if info['Architecture'] not in {'x86_64','amd64'}:
        raise RuntimeError('Docker daemon is not native amd64')
    subprocess.run(['docker','pull',image],check=True,timeout=600)
    inspect=json.loads(subprocess.run(['docker','image','inspect',image],check=True,capture_output=True,text=True).stdout)[0]
    if (inspect['Architecture']!='amd64' or inspect['Config'].get('Volumes')
            or inspect['Config'].get('Labels',{}).get('qfbench2.interface_version')!='2.0'):
        raise RuntimeError('Image platform/interface/VOLUME contract failed')
    expected=json.loads((BASE/'runtime-hashes.json').read_text())
    probe="import hashlib,json,platform,pathlib,sys; expected=json.loads(sys.argv[1]); actual={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in expected}; assert actual==expected; assert platform.machine().lower() in {'x86_64','amd64'}; print(json.dumps({'runtime_sources_match':True,'runtime_machine':platform.machine()}))"
    result=subprocess.run(['docker','run','--rm','--network=none','--read-only','--user','1000:1000',
                '--cap-drop=ALL','--security-opt=no-new-privileges','--tmpfs','/tmp:rw,noexec,nosuid,size=1g',
                '--entrypoint','python',image,'-c',probe,json.dumps(expected)],check=True,capture_output=True,text=True,timeout=120)
    (BASE/'runtime-probe.json').write_text(result.stdout)
    locks=json.loads((BASE/'sources.lock.json').read_text())['repositories']
    for key in ['toolkit','t3']:
        source=locks[key];target=BASE/source['path']
        if target.exists():raise RuntimeError('Preserve existing official cache; use a fresh CI workspace')
        with urllib.request.urlopen(source['archive_url'],timeout=120) as response:
            data=response.read(16*1024*1024+1)
        if hashlib.sha256(data).hexdigest()!=source['archive_sha256']:
            raise RuntimeError('Official archive digest mismatch: '+key)
        with tempfile.TemporaryDirectory() as staging:
            with tarfile.open(fileobj=io.BytesIO(data)) as archive:
                archive.extractall(staging,filter='data')
            entries=list(Path(staging).iterdir())
            if len(entries)!=1 or not entries[0].is_dir():raise RuntimeError('Unexpected source archive layout')
            target.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(entries[0]),target)
    subprocess.run([sys.executable,'-m','pip','install','-r',str(BASE/'requirements.lock.txt')],check=True)
    subprocess.run([sys.executable,'-m','pip','install','--no-deps','--no-build-isolation',
                    str(BASE/locks['toolkit']['path']/'common'),str(BASE/locks['t3']['path'])],check=True)
    subprocess.run([sys.executable,str(BASE/'scripts/hydrate_lfs.py'),'t3'],cwd=BASE,check=True)
    subprocess.run([sys.executable,'-u',str(BASE/'scripts/t3_regression.py'),'--skip-review','--role','candidate',
                    '--image',image,'--docker','docker','--cpus','4','--memory','16g',
                    '--container-user',f'{os.getuid() or 65534}:{os.getgid() if os.getuid() else 65534}'],cwd=BASE,check=True)
    latest=json.loads((BASE/'reports/t3-regression-latest.json').read_text())
    if not latest['complete'] or latest['passed_units']!=71:raise RuntimeError('Incomplete native roster')
    (BASE/'native-validation.json').write_text(json.dumps({'passed':True,'native_amd64_validated':True,
        'image':image,'image_id':inspect['Id'],'host_machine':platform.machine(),
        'host_cpus':info['NCPU'],'host_memory_bytes':info['MemTotal'],'units':71,'runs':355,
        'runtime_sources_match':True,'paid_calls':0,'official_score':None,'rankable':False,
        'official_hardware_equivalent':False,'run_dir':latest['run_dir']},indent=2)+'\n')
    return 0


if __name__=='__main__':
    raise SystemExit(main())
