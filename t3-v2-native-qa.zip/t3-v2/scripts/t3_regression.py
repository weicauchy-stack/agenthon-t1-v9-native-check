#!/usr/bin/env python3
"""Frozen public T3 regression, host-only DeepSeek QA and offline simulator execution.

Never packages DeepSeek into the simulator. Every result is local/developer, not rankable.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from finaldev.config import RUNS, official, sources, write_json
class DeepSeekSimClient:
    def __init__(self, **kwargs):
        raise PermissionError("Paid model calls are disabled in native QA")
from dev import validate


def aggregate(records: list[dict], roster_size: int) -> dict:
    if len(records) > roster_size or len({r['unit'] for r in records}) != len(records):
        raise ValueError('Duplicate units or larger than frozen roster')
    passed = sum(bool(r['passed']) for r in records)
    return {'processed_units': len(records), 'roster_units': roster_size,
            'passed_units': passed, 'failed_units': len(records)-passed,
            'pending_units': roster_size-len(records),
            'complete': len(records) == roster_size,
            'local_mean_rate_fixed_denominator': sum(
                r['local_median_rate'] if r['passed'] else 0.0 for r in records
            ) / roster_size,
            'rankable': False, 'official_score': None}


def lifecycle_seconds(state: dict) -> float:
    # datetime accepts Docker's fractional seconds (microsecond precision is enough locally).
    start = datetime.fromisoformat(state['StartedAt'].replace('Z', '+00:00'))
    finish = datetime.fromisoformat(state['FinishedAt'].replace('Z', '+00:00'))
    elapsed = (finish-start).total_seconds()
    if elapsed <= 0 or state.get('Running'):
        raise ValueError('Missing or invalid finished-container timing')
    return elapsed


def review(client: DeepSeekSimClient, run: Path, phase: str, evidence: dict) -> bool:
    # Only this allowlisted participant plan and compact test evidence leave the host.
    prompt = (
        'Review this T3 LOCAL DEVELOPMENT test, not a simulation runtime. '
        'Respond in Chinese, within 1800 tokens. Identify verified limitations and concrete '
        'missing checks; do not invent scores or claim tests executed. No executable code. '
        'The official scorer remains authoritative. Public references, credentials and '
        'private tasks are NOT provided. T3 runtime is fully offline, no model calls.\n\n'
        + (ROOT/'tracks/t3/T3FINAL_PLAN.md').read_text()
        + '\n\nFrozen test plan: 71 public units, image pinned to local image ID, '
        '5 same-seed repeats, first warmup; official output sanitation and semantic scorer '
        'on EVERY repeat; stable trace/ledger byte hashes; 300s lifecycle check; '
        'Docker StartedAt to FinishedAt measured locally; host Parquet footer row count; '
        'failures zero with fixed 71 denominator; use the recorded actual VM resources '
        'and requested quotas in the evidence, without assuming hardware equivalence; '
        'ARM64, no B200. Cannot claim native amd64 or official C1/C2 telemetry. '
        'All CLI runs are offline/nonroot/readonly, stage solver inputs and card but never references. '
        'If any repeat fails, that unit is marked zero and remaining repeats skipped, '
        'then continue all remaining units.\nEvidence:\n'
        + json.dumps(evidence, ensure_ascii=False)
    )
    body = {'model': 'house', 'messages': [{'role': 'user', 'content': prompt}],
            'max_tokens': 2400, 'temperature': 0, 'seed': 1729,
            'chat_template_kwargs': {'enable_thinking': False}}
    write_json(run/f'deepseek-{phase}-request.json', body)
    try:
        # A full regression may outlast the provider's keep-alive window.
        # Start a fresh verified connection for each review; never hide a POST retry.
        if client.pool is not None:
            client.pool.reset()
        response = client.infer(body, timeout=120, unit=f't3-development-qa-{phase}')
        write_json(run/f'deepseek-{phase}-response.json', response)
        (run/f'deepseek-{phase}.md').write_text(response['choices'][0]['message']['content']+'\n')
        return True
    except Exception as exc:
        write_json(run/f'deepseek-{phase}-error.json', {'type': type(exc).__name__})
        return False
    finally:
        receipt = client.receipt()
        receipt['pricing_reverified_on'] = '2026-10-26'
        receipt['pricing_source'] = 'https://api-docs.deepseek.com/quick_start/pricing/'
        write_json(run/'deepseek-receipts.json', receipt)


def container_user(value: str) -> str:
    parts=value.split(':')
    if len(parts)!=2 or not all(x.isdecimal() for x in parts) or int(parts[0])==0:
        raise argparse.ArgumentTypeError('Use a non-root numeric UID:GID')
    return value


def run_unit(unit: Path, run: Path, image: str, docker: str, cpus: int = 2, memory: str = '4g', user: str = '1000:1000') -> dict:
    from qfbench2_track_simulation.limits import stable_paths_for
    sys.path.insert(0, str(official('t3')))
    from throughput.run_unit import retain_output
    import pyarrow.parquet as pq
    print(json.dumps({'stage':'unit_start','unit':unit.name}),flush=True)
    home = run/unit.name
    staged = home/'input'
    staged.mkdir(parents=True)
    batch = (unit/'batch.json').exists()
    shutil.copy2(unit/'card.toml', staged/'card.toml')
    if batch:
        shutil.copytree(unit/'scenarios', staged/'scenarios')
        shutil.copy2(unit/'batch.json', staged/'batch.json')
        verb = ['simulate-batch', '--batch-dir', '/input/scenarios', '--out-dir', '/output']
    else:
        shutil.copy2(unit/'scenario.json', staged/'scenario.json')
        verb = ['simulate', '--config', '/input/scenario.json', '--out', '/output/trace.parquet']
    stable = stable_paths_for(unit)
    records = []
    for index in range(5):
        repeat = home/f'repeat-{index}'
        raw, clean = repeat/'raw-output', repeat/'output'
        raw.mkdir(parents=True)
        raw.chmod(0o777)
        name = 't3-regression-'+str(time.time_ns())
        command = [docker, 'run', '--name', name, '--network=none', '--read-only',
                   '--user', container_user(user), '--cap-drop=ALL', '--security-opt=no-new-privileges',
                   '--pids-limit', '512', '--ulimit', 'nofile=1024:1024',
                   f'--cpus={cpus}', f'--memory={memory}', f'--memory-swap={memory}',
                   '--tmpfs', '/tmp:rw,noexec,nosuid,nodev,size=64m',
                   '-e', 'QFBENCH_NETWORK=none', '-e', f'QFBENCH_SEED={900000+index}',
                   '-v', f'{staged}:/input:ro', '-v', f'{raw}:/output', image, *verb]
        write_json(repeat/'command.json', command)
        record = {'repeat': index, 'warmup': index == 0, 'admissible': False}
        try:
            print(json.dumps({'stage':'container_start','unit':unit.name,'repeat':index}),flush=True)
            # File-backed logs avoid retaining simulator stdout in controller memory.
            with (repeat/'run.log').open('wb') as log:
                proc = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=315)
            inspection = subprocess.run([docker, 'inspect', name], check=True,
                                        capture_output=True, text=True, timeout=20)
            info = json.loads(inspection.stdout)[0]
            write_json(repeat/'container-state.json', {k: info[k] for k in ['Id','Image','State']})
            record['lifecycle_sec'] = lifecycle_seconds(info['State'])
            record['exit_code'] = proc.returncode
            if proc.returncode != 0 or record['lifecycle_sec'] > 300:
                raise RuntimeError('Container failure or 300-second lifecycle cap exceeded')
            print(json.dumps({'stage':'container_finished','unit':unit.name,'repeat':index,'lifecycle_sec':record['lifecycle_sec']}),flush=True)
            retain_output(raw, clean, unit)  # Official no-follow allowlist and 256MiB limits.
            record['sanitation_passed'] = True
            print(json.dumps({'stage':'official_validation_start','unit':unit.name,'repeat':index}),flush=True)
            record.update(validate('t3', unit, clean))
            print(json.dumps({'stage':'official_validation_finished','unit':unit.name,'repeat':index}),flush=True)
            record['stable_hashes'] = {str(p): hashlib.sha256((clean/p).read_bytes()).hexdigest()
                                       for p in stable}
            traces = [clean/p for p in stable if str(p).endswith('trace.parquet')
                      and not str(p).endswith('message_trace.parquet')]
            record['host_event_rows'] = sum(pq.ParquetFile(p).metadata.num_rows for p in traces)
            record['local_events_per_sec'] = record['host_event_rows']/record['lifecycle_sec']
            # Preserve verified copies, avoid storing the same successful bytes twice.
            # Preserve raw files: platform UID 65534 owns batch directories.
            # Host-side copies were sanitized and validated above.
        except Exception as exc:
            record.update(admissible=False, error_type=type(exc).__name__, error=str(exc)[:1500])
        finally:
            subprocess.run([docker, 'rm', '--force', name], capture_output=True, timeout=20)
        write_json(repeat/'validation.json', record)
        records.append(record)
        if not record['admissible']:
            break
    consistent = len(records) == 5 and all(
        r.get('stable_hashes') == records[0].get('stable_hashes') for r in records)
    passed = consistent and all(r['admissible'] for r in records)
    result = {'unit': unit.name, 'batch': batch, 'passed': passed,
              'repeats_completed': len(records), 'repeats_planned': 5,
              'stable_outputs_match': consistent,
              'local_median_rate': statistics.median(r['local_events_per_sec'] for r in records[1:])
                                   if passed else 0.0,
              'rankable': False, 'records': records}
    write_json(home/'summary.json', result)
    return result


def main() -> int:
    import faulthandler
    faulthandler.enable()
    faulthandler.dump_traceback_later(120,repeat=True)
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--allow-paid', action='store_true')
    ap.add_argument('--skip-review', action='store_true', help='Offline rerun; make zero model calls')
    ap.add_argument('--cpus', type=int, choices=range(1, 5), default=2)
    ap.add_argument('--memory', choices=['4g', '16g'], default='4g')
    ap.add_argument('--container-user', type=container_user, default='1000:1000')
    ap.add_argument('--image', default='agenthon-final/t3-reference:local-arm64')
    ap.add_argument('--role', choices=['reference','candidate'], default='reference')
    ap.add_argument('--reference-summary', type=Path, help='Host-only stable hashes from the complete reference run')
    ap.add_argument('--docker', default=str(ROOT.parent/'.runtime/bin/docker'))
    args = ap.parse_args()
    if not args.allow_paid and not args.skip_review:
        ap.error('User-authorized DeepSeek call requires --allow-paid')
    client = None if args.skip_review else DeepSeekSimClient(allow_paid=True, budget_usd='0.10', max_requests=2)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    run = RUNS/('t3-'+args.role+'-regression-'+stamp)
    run.mkdir(parents=True)
    units = sorted(p.parent for p in (official('t3')/'units').glob('*/card.toml'))
    if len(units) != 71:
        raise ValueError('Public roster changed; expected 71 units')
    expected_hashes = {}
    if args.reference_summary:
        reference = json.loads(args.reference_summary.read_text())
        if (not reference['complete'] or reference['passed_units'] != 71
                or [x['unit'] for x in reference['records']] != [u.name for u in units]):
            raise ValueError('Reference summary is not a complete passing frozen roster')
        expected_hashes = {x['unit']: x['records'][0]['stable_hashes'] for x in reference['records']}
    image_info = json.loads(subprocess.run([args.docker, 'image', 'inspect', args.image],
                           check=True, capture_output=True, text=True, timeout=30).stdout)[0]
    pinned = image_info['Id']
    vm_info = json.loads(subprocess.run([args.docker, 'info', '--format', '{{json .}}'],
                         check=True, capture_output=True, text=True, timeout=30).stdout)
    plan = {'run_dir': str(run), 'scope': 'T3 offline public '+args.role+' regression with optional host-only QA',
            'image_tag': args.image, 'image_id': pinned, 'architecture': image_info['Architecture'],
            'roster': [u.name for u in units], 'repeats': 5, 'rankable': False,
            'official_hardware_equivalent': False, 'native_amd64_validated': False,
            'resources_requested': {'cpus': args.cpus, 'memory': args.memory, 'network': 'none'},
            'actual_vm_resources': {'cpus': vm_info['NCPU'], 'memory_bytes': vm_info['MemTotal']},
            'deepseek_calls_enabled': client is not None,
            'container_user': args.container_user,
            'tmpfs': '/tmp:rw,noexec,nosuid,nodev,size=64m',
            'reference_summary': str(args.reference_summary) if args.reference_summary else None,
            'sources': sources(), 'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    write_json(run/'protocol.json', plan)
    print(json.dumps({'run_dir': str(run), 'units': len(units), 'image_id': pinned}), flush=True)
    shutil.copy2(Path(__file__).resolve(), run/'controller.py')
    if client is not None:
        ok = review(client, run, 'preflight', {'plan': {k:v for k,v in plan.items() if k not in {'sources','roster'}}})
        print('DeepSeek preflight response: '+str(ok), flush=True)
    records = []
    for unit in units:
        result = run_unit(unit, run, pinned, args.docker, args.cpus, args.memory,args.container_user)
        if expected_hashes:
            result['reference_stable_outputs_match'] = bool(result['passed']) and all(
                x['stable_hashes'] == expected_hashes[unit.name] for x in result['records'])
            if not result['reference_stable_outputs_match']:
                result.update(passed=False, local_median_rate=0.0)
            write_json(run/unit.name/'summary.json', result)
        records.append(result)
        summary = {**aggregate(records, len(units)), 'run_dir': str(run),
                   'limitations': [image_info['Architecture']+' local '+args.role+' image; native amd64 acceptance not established',
                                   f"Requested {args.cpus}CPU/{args.memory}; VM {vm_info['NCPU']}CPU/{vm_info['MemTotal']} bytes; no B200",
                                   'Local lifecycle timing, no official signed C1/C2 evidence'],
                   'records': records}
        write_json(run/'summary.json', summary)
        write_json(ROOT/'reports/t3-regression-latest.json', {k:v for k,v in summary.items() if k!='records'})
        print(json.dumps({**{k:result[k] for k in ['unit','passed','repeats_completed','stable_outputs_match']},
                          'processed': len(records), 'total': len(units)}, ensure_ascii=False), flush=True)
    compact = {k:v for k,v in summary.items() if k!='records'}
    compact['failures'] = [{'unit': r['unit'], 'records': [x for x in r['records'] if not x['admissible']]}
                           for r in records if not r['passed']]
    if client is not None and not client.fatal:
        ok = review(client, run, 'results', compact)
        print('DeepSeek results response: '+str(ok), flush=True)
    write_json(run/'completion.json', {**compact, 'deepseek': client.receipt() if client else {'paid_attempts': 0}})
    print(json.dumps(compact, ensure_ascii=False), flush=True)
    return 0 if summary['passed_units']==len(units) else 1


if __name__ == '__main__':
    raise SystemExit(main())
