#!/usr/bin/env python3
"""Materialize public Git LFS objects from a pinned organizer snapshot.

GitHub source archives can contain pointers instead of parquet files. Verify both
the pointer's SHA256 and size before replacing it with the actual public data.
"""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time
import urllib.parse

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from finaldev.config import official, sources, write_json

POINTER = re.compile(r"version https://git-lfs.github.com/spec/v1\noid sha256:([0-9a-f]{64})\nsize ([0-9]+)\n?")


def hydrate(track: str) -> dict:
    source = sources()["repositories"][track]
    root = official(track)
    pending = []
    for p in root.rglob("*"):
        if p.is_file() and p.stat().st_size < 200:
            match = POINTER.fullmatch(p.read_text(errors="replace"))
            if match:
                pending.append((p, match.group(1), int(match.group(2))))

    def download(entry):
        path, expected, size = entry
        rel = path.relative_to(root).as_posix()
        url = f"https://media.githubusercontent.com/media/{source['repository']}/{source['commit']}/{urllib.parse.quote(rel, safe='/')}"
        last = None
        for attempt in range(3):
            try:
                r = subprocess.run(["/usr/bin/curl", "--fail", "--silent", "--show-error", "--location", "--max-time", "120", url],
                                   check=True, capture_output=True)
                blob = r.stdout
                if len(blob) != size or hashlib.sha256(blob).hexdigest() != expected:
                    raise ValueError(f"LFS object size/hash mismatch for {rel}")
                staging = path.with_suffix(path.suffix+".lfs-download")
                staging.write_bytes(blob)
                staging.replace(path)
                return {"path": rel, "sha256": expected, "bytes": size}
            except Exception as exc:
                last = exc
                time.sleep(attempt+1)
        raise RuntimeError(f"Unable to materialize {rel}: {last}")

    with ThreadPoolExecutor(max_workers=6) as pool:
        completed = list(pool.map(download, pending))
    report = {"track": track, "source_commit": source["commit"], "files_materialized": len(completed),
              "bytes_materialized": sum(x["bytes"] for x in completed), "files": completed}
    write_json(ROOT/"reports"/f"{track}-lfs-hydration.json", report)
    return {k:v for k,v in report.items() if k != "files"}


if __name__ == "__main__":
    track = sys.argv[1] if len(sys.argv)>1 else "t3"
    if track not in {"t1","t2","t3"}:
        raise SystemExit("Choose t1, t2 or t3")
    print(json.dumps(hydrate(track), indent=2))
