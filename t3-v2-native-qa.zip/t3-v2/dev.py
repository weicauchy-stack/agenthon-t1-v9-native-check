#!/usr/bin/env python3
"""Local Final development commands. Nothing here publishes, signs or uploads."""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib
from importlib import metadata
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time
import tomllib

from finaldev.config import ROOT, RUNS, TRACKS, official, sources, unit_path, write_json


def stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")


def inventory() -> dict:
    report = {"sources": sources(), "tracks": {}}
    for track in TRACKS:
        units = []
        for path in sorted((official(track) / "units").glob("*/card.toml")):
            c = tomllib.loads(path.read_text())
            item = {
                "id": c["task"]["id"], "split": c["task"]["split"],
                "category": c.get("metadata", {}).get("category"),
                "family": c["task"].get("scenario_family"),
                "target_type": c.get("targets", {}).get("target_type"),
                "assets": c.get("targets", {}).get("asset_ids", []),
                "horizons": c.get("targets", {}).get("horizons", []),
                "timeout_sec": c.get("agent", {}).get("timeout_sec"),
                "has_published_practice_answer": (official(track) / "practice-answers" / (path.parent.name + ".parquet")).is_file(),
                "batch": (path.parent / "scenarios").is_dir(),
                "semantic_tier": c.get("scoring", {}).get("params", {}).get("semantic_tier"),
            }
            units.append(item)
        report["tracks"][track] = {
            "count": len(units), "categories": dict(Counter(u["category"] for u in units)),
            "splits": dict(Counter(u["split"] for u in units)),
            "published_practice_answers": sum(u["has_published_practice_answer"] for u in units),
            "batch_units": sum(u["batch"] for u in units), "units": units,
        }
    write_json(ROOT / "reports" / "inventory.json", report)
    return {k: {n: v for n, v in t.items() if n != "units"} for k, t in report["tracks"].items()}


def doctor() -> dict:
    distributions = ["qfbench2-common", "qfbench2-track-coding", "qfbench2-track-forecasting",
                     "qfbench2-track-simulation", "numpy", "scipy", "pandas", "pyarrow", "pytest"]
    versions = {}
    for name in distributions:
        try:
            versions[name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            versions[name] = None
    report = {"python": sys.version.split()[0], "executable": sys.executable,
              "packages": versions, "snapshots": {k: official(k).exists() for k in ["toolkit", *TRACKS]},
              "house_credentials_present": all(bool(__import__("os").environ.get(k)) for k in ["MODEL_ENDPOINT", "MODEL_TOKEN", "MODEL_NAME"]),
              "t3_runtime": "Separate Python 3.11 Docker image; host Python 3.13 only scores outputs",
              "ready_for_host_development": sys.version_info >= (3, 13) and all(versions.values()),
              "final_upload_ready": False}
    write_json(ROOT / "reports" / "environment.json", report)
    return report


def validate(track: str, unit: Path, output: Path, realized: Path | None = None) -> dict:
    from qfbench2_common.manifest import verify_manifest
    errors = verify_manifest(unit)
    if errors:
        raise ValueError(f"Organizer input manifest mismatch: {errors[:3]}")
    if track == "t2":
        cmd = [sys.executable, str(official(track) / "scoring/scoring.py"), "score",
               "--card", str(unit / "card.toml"), "--forecast", str(output / "forecast.parquet")]
        if realized is not None:
            cmd += ["--realized", str(realized)]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
        if not r.stdout.strip():
            raise RuntimeError(f"Official scorer exited {r.returncode}: {r.stderr[-2000:]}")
        data = json.loads(r.stdout)
        data["scored"] = "composite_score" in data
        data["scorer_exit_code"] = r.returncode
        return data
    from qfbench2_common.smoke import run_smoke, resolve_verifier_factory
    module = importlib.import_module(f"qfbench2_track_{TRACKS[track]}.scoring")
    name, factory = resolve_verifier_factory(module, "smoke")
    verdict = run_smoke(unit, output, factory)
    return {"admissible": verdict.admissible, "score": verdict.score,
            "labels": [x.value for x in verdict.labels], "factory": name,
            "gates": {k: v.passed for k, v in verdict.gate_results.items()},
            "detail": verdict.detail, "rankable": False}


def t2_baseline(selection: str, limit: int | None) -> tuple[dict, bool]:
    units = sorted((official("t2") / "units").glob("*/card.toml"))
    if selection == "short":
        units = [p for p in units if p.parent.name.endswith("-ps1")]
    if limit:
        units = units[:limit]
    run = RUNS / ("t2-reference-" + stamp())
    records = []
    for card in units:
        unit = card.parent
        c = tomllib.loads(card.read_text())
        output = run / unit.name / "output"
        output.mkdir(parents=True)
        started = time.monotonic()
        command = [sys.executable, str(ROOT / "tracks/t2/agent.py"), "forecast", "--method", "reference",
                   "--panels", str(unit / "panels"), "--text", str(unit / "text"),
                   "--asof", str(c["provenance"]["data_cutoff"]),
                   "--out", str(output / "forecast.parquet"), "--seed", "1729", "--n-draws", "1000"]
        try:
            p = subprocess.run(command, capture_output=True, text=True, timeout=120)
            (output.parent / "run.log").write_text(p.stdout + p.stderr)
            if p.returncode:
                raise RuntimeError(f"Forecaster exited {p.returncode}; see run.log")
            answer = official("t2") / "practice-answers" / (unit.name + ".parquet")
            result = validate("t2", unit, output, answer if answer.is_file() else None)
        except Exception as exc:
            result = {"admissible": False, "error": str(exc), "scored": False}
        record = {"unit": unit.name, "category": c.get("metadata", {}).get("category"),
                  "elapsed_sec": time.monotonic() - started, **result}
        write_json(output.parent / "validation.json", record)
        records.append(record)
        print(f"{unit.name}: admissible={record['admissible']} scored={record.get('scored', False)}", flush=True)
    summary = {"run_dir": str(run), "method": "official reference, text-blind, seed=1729, 1000 draws",
               "units": len(records), "admissible": sum(r["admissible"] for r in records),
               "scored_units": sum(r.get("scored", False) for r in records),
               "rankable": False, "score_interpretation": "raw per-card only; do not average raw losses across assets or claim a Final score",
               "records": records}
    write_json(run / "summary.json", summary)
    write_json(ROOT / "reports/t2-baseline-latest.json", {k:v for k,v in summary.items() if k != "records"})
    return summary, bool(records) and all(r["admissible"] for r in records)


def t3_run(unit_name: str, image: str, repeats: int, docker: str, cpus: float = 2, memory: str = "4g") -> tuple[dict, bool]:
    unit = unit_path("t3", unit_name)
    run = RUNS / ("t3-" + unit_name + "-" + stamp())
    staged = run / "input"
    staged.mkdir(parents=True)
    batch = (unit / "scenarios").is_dir()
    if batch:
        shutil.copytree(unit / "scenarios", staged / "scenarios")
        verb = ["simulate-batch", "--batch-dir", "/input/scenarios", "--out-dir", "/output"]
    else:
        shutil.copy2(unit / "scenario.json", staged / "scenario.json")
        verb = ["simulate", "--config", "/input/scenario.json", "--out", "/output/trace.parquet"]
    records, bindings = [], []
    from qfbench2_track_simulation.limits import stable_paths_for
    stable_paths = stable_paths_for(unit)
    for index in range(repeats):
        output = run / f"repeat-{index}" / "output"
        output.mkdir(parents=True)
        output.chmod(0o777)
        container_name = "agenthon-final-" + stamp().lower()
        cmd = [docker, "run", "--rm", "--name", container_name, "--network=none", "--read-only", "--user", "1000:1000",
               "--cap-drop=ALL", "--security-opt=no-new-privileges", "--pids-limit", "512",
               "--ulimit", "nofile=1024:1024", f"--cpus={cpus}", f"--memory={memory}", f"--memory-swap={memory}",
               "--tmpfs", "/tmp:rw,noexec,nosuid,size=1g", "-v", f"{staged}:/input:ro",
               "-v", f"{output}:/output", image, *verb]
        try:
            p = subprocess.run(cmd, capture_output=True, text=True, timeout=315)
            (output.parent / "run.log").write_text(p.stdout + p.stderr)
            if p.returncode:
                raise RuntimeError(f"Container exited {p.returncode}; see run.log")
            result = validate("t3", unit, output)
            hashes = {str(path): hashlib.sha256((output / path).read_bytes()).hexdigest() for path in stable_paths}
            bindings.append(hashes)
            result["stable_hashes"] = hashes
        except subprocess.TimeoutExpired:
            subprocess.run([docker, "rm", "--force", container_name], capture_output=True, timeout=15)
            result = {"admissible": False, "error": "Local container deadline reached; container removed"}
        except Exception as exc:
            result = {"admissible": False, "error": str(exc)}
        records.append(result)
        write_json(output.parent / "validation.json", result)
        if not result["admissible"]:
            break  # A failed rehearsal is actionable; do not spend four more timeout windows.
    stable = len(bindings) == repeats and all(h == bindings[0] for h in bindings)
    success = len(records) == repeats and all(r["admissible"] for r in records) and stable
    report = {"unit": unit_name, "image": image, "run_dir": str(run), "repeats": repeats,
              "admissible_repeats": sum(r["admissible"] for r in records),
              "stable_outputs_match": stable, "rankable": False,
              "local_resources": {"cpus": cpus, "memory": memory, "gpu": False},
              "limitations": "Local CPU rehearsal; no B200, trusted C1/C2 timing or official Final score",
              "records": records}
    write_json(run / "summary.json", report)
    write_json(ROOT / "reports/t3-baseline-latest.json", report)
    return report, success


def descriptor(args) -> dict:
    from qfbench2_common.contracts.descriptor import seal_descriptor_digest, SubmissionDescriptor
    if len(args.digest) != 71 or not args.digest.startswith("sha256:") or args.digest == "sha256:" + "0"*64:
        raise ValueError("Supply a real sha256 image digest")
    if not args.team_id.startswith("team-") or "example" in args.team_id:
        raise ValueError("Use your derived public team alias, not a fixture team ID")
    track = TRACKS[args.track]
    path = official("toolkit") / f"common/qfbench2_common/contracts/fixtures/c5/{track}_final.json"
    data = json.loads(path.read_text())
    data.update(competition_id=f"agenthon2026-{track}-final", phase="final", team_id=args.team_id,
                category="simulator" if args.track == "t3" else "api", image_access="public", license="MIT",
                image={"registry": args.registry, "repository": args.repository, "digest": args.digest}, models=[])
    if args.track == "t1" or args.house:
        if args.track == "t3":
            raise ValueError("T3 cannot use the House model")
        data["models"] = [{"name":"nvidia/nemotron-3-super-120b-a12b", "version":"rl-030326-fp8",
                           "revision":"rl-030326-fp8", "training_cutoff":"unpublished", "access":"api"}]
    data = seal_descriptor_digest(data)
    SubmissionDescriptor.from_mapping(data)
    if args.out.exists():
        raise FileExistsError(f"Refusing to overwrite {args.out}")
    write_json(args.out, data)
    return {"descriptor": str(args.out), "valid": True, "phase": "final", "signed": False, "uploaded": False}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("doctor")
    commands.add_parser("inventory")
    context = commands.add_parser("t1-context")
    context.add_argument("unit")
    t2 = commands.add_parser("t2-baseline")
    t2.add_argument("--set", choices=["short", "all"], default="short")
    t2.add_argument("--limit", type=int)
    t3 = commands.add_parser("t3-run")
    t3.add_argument("unit")
    t3.add_argument("--image", default="agenthon-final/t3-reference:2fa71ea2468d")
    t3.add_argument("--repeats", type=int, default=5, choices=range(1, 6))
    t3.add_argument("--docker", default=str(ROOT.parent / ".runtime/bin/docker"))
    t3.add_argument("--cpus", type=float, default=2, help="Local quota; official Final grants 4")
    t3.add_argument("--memory", default="4g", help="Local cap; official Final grants 16 GiB")
    val = commands.add_parser("validate")
    val.add_argument("track", choices=TRACKS)
    val.add_argument("unit")
    val.add_argument("output", type=Path)
    draft = commands.add_parser("descriptor")
    draft.add_argument("track", choices=TRACKS)
    for key in ["team-id", "registry", "repository", "digest"]:
        draft.add_argument("--" + key, required=True)
    draft.add_argument("--house", action="store_true")
    draft.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    ok = True
    if args.command == "doctor":
        result = doctor()
        ok = result["ready_for_host_development"]
    elif args.command == "inventory":
        result = inventory()
    elif args.command == "t1-context":
        import importlib.util
        spec = importlib.util.spec_from_file_location("t1_agent", ROOT / "tracks/t1/agent.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        data = module.task_context(unit_path("t1", args.unit))
        path = RUNS / ("t1-context-" + stamp()) / "context.json"
        write_json(path, data)
        result = {"context": str(path), "house_called": False, "agent_executed": False}
    elif args.command == "t2-baseline":
        full, ok = t2_baseline(args.set, args.limit)
        result = {k:v for k,v in full.items() if k != "records"}
    elif args.command == "t3-run":
        full, ok = t3_run(args.unit, args.image, args.repeats, args.docker, args.cpus, args.memory)
        result = {k:v for k,v in full.items() if k != "records"}
    elif args.command == "descriptor":
        result = descriptor(args)
    else:
        result = validate(args.track, unit_path(args.track, args.unit), args.output.resolve())
        ok = result["admissible"]
    print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
